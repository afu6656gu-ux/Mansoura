// عرض صفحة الحجز
function showBookingPage() {
    document.getElementById('bookingStep1').classList.add('active');
    window.scrollTo({
        top: document.getElementById('bookingStep1').offsetTop - 50,
        behavior: 'smooth'
    });
}
// باقي الكود JavaScript مأخوذ من المستخدم
